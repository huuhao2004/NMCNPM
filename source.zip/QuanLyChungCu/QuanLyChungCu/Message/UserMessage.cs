﻿namespace QuanLyChungCu.Message
{
    class UserMessage
    {
        public static string Validate = "Vui lòng nhập đầy đủ thông tin!";
        public static string Login_success = "Đăng nhập thành công";
        public static string Login_fail = "Đăng nhập thất bại, kiểm tra lại thông tin";
        public static string UpdatePass_success = "Thay đổi mật khẩu thành công";
        public static string UpdatePass_fail = "Mật khẩu cũ không chính xác. Vui lòng kiểm tra lại!";
        public static string UpdatePass_Validate = "Vui lòng nhập đầy đủ thông tin!";
        public static string UpdatePassNew1 = "Xác nhận mật khẩu không chính xác!";
    }
}
