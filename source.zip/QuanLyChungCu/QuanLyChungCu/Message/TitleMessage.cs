﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyChungCu.Message
{
     class TitleMessage
    {
        public static string TITLE_INFO = "Thông báo";
        public static string TITLE_WARNING = "Cảnh báo";
        public static string TITLE_ERROR = "Lỗi";
    }

}
