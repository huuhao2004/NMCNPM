﻿namespace QuanLyChungCu.ViewModel
{
    public class SelectText
    {
        public object Value { get; set; }
        public string Text { get; set; }

        public SelectText() { }
        public SelectText(object value, string text)
        {
            Value = value;
            Text = text;
        }
    }
}
