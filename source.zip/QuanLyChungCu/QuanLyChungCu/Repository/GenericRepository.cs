﻿using QuanLyChungCu.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;

namespace QuanLyChungCu.Repository
{
    public interface IRepository<T>
    {
        bool Insert(T entity);
        bool Update(T entity);
        bool Delete(object id);
        T FindById(object id);
        List<T> GetAll(string includeProperties = null);
        T Find(Expression<Func<T, bool>> expression);
        List<T> FindAll(Expression<Func<T, bool>> expression);
    }

    public class GenericRepository<T> : IRepository<T>, IDisposable where T : class
    {
        public QuanLyChungCuEntities _context;
        private IDbSet<T> _entities;
        private bool _isDisposed;
        public GenericRepository()
        {
            _context = new QuanLyChungCuEntities();
        }
        private IDbSet<T> Entities
        {
            get
            {
                if (_entities == null)
                {
                    _entities = _context.Set<T>();
                }
                return _entities;
            }
        }

        public virtual IQueryable<T> Table
        {
            get
            {
                return this.Entities;
            }
        }


        public void Dispose()
        {
            if (_context != null)
                _context.Dispose();
            _isDisposed = true;
        }

        public T Find(Expression<Func<T, bool>> expression)
        {
            return Entities.FirstOrDefault(expression);
        }

        public List<T> FindAll(Expression<Func<T, bool>> expression)
        {
            _context.Configuration.ProxyCreationEnabled = false;
            return Entities.Where(expression).ToList();
        }

        public bool Delete(object id)
        {
            using (var context = new QuanLyChungCuEntities())
            {
                T obj = context.Set<T>().Find(id);
                if (obj == null)
                    return false;

                context.Set<T>().Remove(obj);
                context.SaveChanges();
            }

            return true;
        }

        public T FindById(object id)
        {
            using (var context = new QuanLyChungCuEntities())
            {
                return context.Set<T>().Find(id);
            }
        }


        public List<T> GetAll(string includeProperties = null)
        {
            using (var context = new QuanLyChungCuEntities())
            {
                var dbSet = context.Set<T>();
                if (includeProperties != null)
                {
                    string[] splitInclude = includeProperties.Split(',');
                    foreach (string s in splitInclude)
                        dbSet = (DbSet<T>)dbSet.Include(s);
                }
                return context.Set<T>().ToList();
            }
        }

        public bool Insert(T entity)
        {
            if (entity == null)
                return false;

            using (var context = new QuanLyChungCuEntities())
            {
                context.Set<T>().Add(entity);
                context.SaveChanges();
            }

            return true;
        }


        public bool Update(T entity)
        {
            if (entity == null)
                return false;

            using (var context = new QuanLyChungCuEntities())
            {
                context.Entry(entity).State = EntityState.Modified;
                context.SaveChanges();
            }

            return true;
        }



        public void SetEntryModified(T entity)
        {
            _context.Entry(entity).State = EntityState.Modified;
        }
    }
}
