﻿using DevExpress.Data.ODataLinq.Helpers;
using QuanLyChungCu.Models;
using QuanLyChungCu.Repository;
using System;
using System.Collections.Generic;
using System.Linq;

namespace QuanLyChungCu.DAO
{
    public class PhiQuanLyDAO : GenericRepository<PhiQuanLy>
    {
        public List<PhiQuanLy> GetListByMaHK(string maHK, int nam)
        {
            if (!string.IsNullOrEmpty(maHK))
                maHK = maHK.ToLower();
            List<PhiQuanLy> list = _context.PhiQuanLy.Where(x => x.MaHoKhau.ToLower().Contains(maHK)).ToList();
            if (nam != 0)
                list = list.Where(x => x.Nam == nam).ToList();
            return list;
        }
        public List<PhiQuanLy> GetListByMaHK(string maHK)
        {
            return _context.PhiQuanLy.Where(x => x.MaHoKhau.ToLower().Contains(maHK.ToLower())).ToList();
        }
        public List<PhiQuanLy> GetListByNam(int nam)
        {
            return _context.PhiQuanLy.Where(x => x.Nam == int.Parse(nam.ToString())).ToList();
        }

        public decimal GetMoney(string maHK, int nam, int thang)
        {
            var money = _context.PhiQuanLy.SingleOrDefault(x => x.MaHoKhau == maHK && x.Nam == nam);
            if (money == null)
                return 0;
            decimal result = 0;
            switch (thang)
            {
                case 1:
                    result = money.Thang1 ?? 0;
                    break;
                case 2:
                    result = money.Thang2 ?? 0;
                    break;
                case 3:
                    result = money.Thang3 ?? 0;
                    break;
                case 4:
                    result = money.Thang4 ?? 0;
                    break;
                case 5:
                    result = money.Thang5 ?? 0;
                    break;
                case 6:
                    result = money.Thang6 ?? 0;
                    break;
                case 7:
                    result = money.Thang7 ?? 0;
                    break;
                case 8:
                    result = money.Thang8 ?? 0;
                    break;
                case 9:
                    result = money.Thang9 ?? 0;
                    break;
                case 10:
                    result = money.Thang10 ?? 0;
                    break;
                case 11:
                    result = money.Thang11 ?? 0;
                    break;
                case 12:
                    result = money.Thang12 ?? 0;
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(thang), "Tháng phải nằm trong khoảng từ 1 đến 12.");
            }

            return result;
        }

        public bool UpdatePhiQuanLy(PhiQuanLy model, int thang)
        {
            try
            {
                var phi = _context.PhiQuanLy.SingleOrDefault(x => x.MaHoKhau == model.MaHoKhau && x.Nam == model.Nam);
                if (phi == null)
                {
                    Insert(model);
                }
                else
                {
                    switch (thang)
                    {
                        case 1:
                            if (phi.Thang1 != model.Thang1)
                                phi.Thang1 = model.Thang1;
                            break;
                        case 2:
                            if (phi.Thang2 != model.Thang2)
                                phi.Thang2 = model.Thang2;
                            break;
                        case 3:
                            if (phi.Thang3 != model.Thang3)
                                phi.Thang3 = model.Thang3;
                            break;
                        case 4:
                            if (phi.Thang4 != model.Thang4)
                                phi.Thang4 = model.Thang4;
                            break;
                        case 5:
                            if (phi.Thang5 != model.Thang5)
                                phi.Thang5 = model.Thang5;
                            break;
                        case 6:
                            if (phi.Thang6 != model.Thang6)
                                phi.Thang6 = model.Thang6;
                            break;
                        case 7:
                            if (phi.Thang7 != model.Thang7)
                                phi.Thang7 = model.Thang7;
                            break;
                        case 8:
                            if (phi.Thang8 != model.Thang8)
                                phi.Thang8 = model.Thang8;
                            break;
                        case 9:
                            if (phi.Thang9 != model.Thang9)
                                phi.Thang9 = model.Thang9;
                            break;
                        case 10:
                            if (phi.Thang10 != model.Thang10)
                                phi.Thang10 = model.Thang10;
                            break;
                        case 11:
                            if (phi.Thang11 != model.Thang11)
                                phi.Thang11 = model.Thang11;
                            break;
                        case 12:
                            if (phi.Thang12 != model.Thang12)
                                phi.Thang12 = model.Thang12;
                            break;
                        default:
                            throw new ArgumentOutOfRangeException(nameof(thang), "Tháng phải nằm trong khoảng từ 1 đến 12.");
                    }
                    _context.SaveChanges();
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
