﻿using QuanLyChungCu.Models;
using QuanLyChungCu.Repository;
using System.Collections.Generic;
using System.Linq;

namespace QuanLyChungCu.DAO
{
    public class HoKhauDAO : GenericRepository<HoKhau>
    {
        public bool IsExistAnotherTable(string maHK)
        {
            if (string.IsNullOrEmpty(maHK))
                return false;
            if (_context.NhanKhau.Any(x => x.MaHoKhau == maHK)) return true;
            if (_context.PhiDongGop.Any(x => x.MaHoKhau == maHK)) return true;
            if (_context.PhiGiuXe.Any(x => x.MaHoKhau == maHK)) return true;
            if (_context.PhiQuanLy.Any(x => x.MaHoKhau == maHK)) return true;
            if (_context.PhiSinhHoat.Any(x => x.MaHoKhau == maHK)) return true;
            if (_context.ThanhToan.Any(x => x.MaHoKhau == maHK)) return true;
            return false;
        }

        public List<HoKhau> GetListByMaHK(string maHK)
        {
            return _context.HoKhau.Where(x => x.MaHoKhau.ToLower().Contains(maHK.ToLower())).ToList();
        }
    }
}
