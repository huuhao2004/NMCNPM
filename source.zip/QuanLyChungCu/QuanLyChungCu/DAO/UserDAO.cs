﻿using QuanLyChungCu.Models;
using QuanLyChungCu.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyChungCu.DAO
{
    internal class UserDAO : GenericRepository<Users>
    {
        public Users GetDataByUserName(String userName, string password)
        {
            return Find(m => m.UserName.Equals(userName) && m.Password.Equals(password));
        }
        public Users GetDataByUserName(string name)
        {
            return Find(m=>m.UserName.Equals(name));
        }
    }
}
