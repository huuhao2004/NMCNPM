﻿using QuanLyChungCu.Models;
using QuanLyChungCu.Repository;

namespace QuanLyChungCu.DAO
{
    public class LoaiPhiDAO : GenericRepository<LoaiPhi>
    {
    }
}
