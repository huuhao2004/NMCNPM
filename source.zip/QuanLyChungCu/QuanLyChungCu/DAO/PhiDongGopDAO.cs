﻿using QuanLyChungCu.Models;
using QuanLyChungCu.Repository;
using System.Collections.Generic;
using System.Linq;

namespace QuanLyChungCu.DAO
{
    public class PhiDongGopDAO : GenericRepository<PhiDongGop>
    {
        public List<PhiDongGop> GetListByMaHK(string maHK)
        {
            List<PhiDongGop> list = _context.PhiDongGop.Where(x => x.MaHoKhau.ToLower().Contains(maHK)).ToList();
            return list;
        }
    }
}
