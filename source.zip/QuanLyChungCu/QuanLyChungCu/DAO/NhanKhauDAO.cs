﻿using QuanLyChungCu.Models;
using QuanLyChungCu.Repository;
using System.Linq;

namespace QuanLyChungCu.DAO
{
    public class NhanKhauDAO : GenericRepository<NhanKhau>
    {
        public bool IsExistCCCD(string cccd)
        {
            return _context.NhanKhau.Any(x => x.SoCMND_CCCD == cccd);
        }
    }
}
