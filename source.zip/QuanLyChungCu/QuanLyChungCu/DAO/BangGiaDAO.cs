﻿using QuanLyChungCu.Models;
using QuanLyChungCu.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyChungCu.DAO
{
    internal class BangGiaDAO : GenericRepository<BangGiaPhi>
    {
    }
}
