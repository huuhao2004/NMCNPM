﻿using QuanLyChungCu.Models;
using QuanLyChungCu.Repository;
using System.Linq;

namespace QuanLyChungCu.DAO
{
    public class BangGiaPhiDAO : GenericRepository<BangGiaPhi>
    {
        public BangGiaPhi GetLast()
        {
            return _context.BangGiaPhi.OrderByDescending(x => x.NgayTao).FirstOrDefault();
        }
    }
}
