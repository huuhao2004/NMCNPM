﻿using QuanLyChungCu.Models;
using QuanLyChungCu.Repository;
using System.Collections.Generic;
using System.Linq;

namespace QuanLyChungCu.DAO
{
    public class PhiSinhHoatDAO : GenericRepository<PhiSinhHoat>
    {
        public List<PhiSinhHoat> GetListByMaHK(string maHK, int nam)
        {
            if (!string.IsNullOrEmpty(maHK))
                maHK = maHK.ToLower();
            List<PhiSinhHoat> list = _context.PhiSinhHoat.Where(x => x.MaHoKhau.ToLower().Contains(maHK)).ToList();
            if (nam != 0)
                list = list.Where(x => x.Nam == nam).ToList();
            return list;
        }
    }
}