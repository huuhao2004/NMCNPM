﻿using QuanLyChungCu.Models;
using QuanLyChungCu.Repository;
using System.Collections.Generic;
using System.Linq;

namespace QuanLyChungCu.DAO
{
    public class PhiGiuXeDAO : GenericRepository<PhiGiuXe>
    {
        public List<PhiGiuXe> GetListByMaHK(string maHK, int nam)
        {
            if (!string.IsNullOrEmpty(maHK))
                maHK = maHK.ToLower();
            List<PhiGiuXe> list = _context.PhiGiuXe.Where(x => x.MaHoKhau.ToLower().Contains(maHK)).ToList();
            if (nam != 0)
                list = list.Where(x => x.Nam == nam).ToList();
            return list;
        }
    }
}
