﻿using QuanLyChungCu.DAO;
using QuanLyChungCu.Models;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace QuanLyChungCu.GUI
{
    public partial class fUpdateUser : Form
    {
        private List<Users> listUsers;
        private UserDAO _daoUserDAO;
        private int row = -1;

        #region Menthos
        public fUpdateUser()
        {
            InitializeComponent();
            LoadForm();
        }
        private void LoadForm()
        {
            _daoUserDAO = new UserDAO();
        }
        private bool ValidateData()
        {
            if (string.IsNullOrEmpty(txtPass.Text) || string.IsNullOrEmpty(txtPassNew.Text) || string.IsNullOrEmpty(txtPassNew1.Text))
                return false;
            return true;
        }
        private void ShowMessage(string message, string content = null)
        {
            if (content != null)
            {
                MessageBox.Show(message, content);
            }
            else
                MessageBox.Show(message);
        }
        private void Update()
        {
            string pass = txtPass.Text;
            string passNew = txtPassNew.Text;
            string passNew1 = txtPassNew1.Text;
            if (!ValidateData())
            {
                ShowMessage(Message.UserMessage.UpdatePass_Validate, Message.TitleMessage.TITLE_WARNING);
                return;
            }
            Users users = _daoUserDAO.GetDataByUserName(fDangNhap.UserData.UserName);
            if (users.Password == pass)
            {
                if (passNew == passNew1)
                {
                    ShowMessage(Message.UserMessage.UpdatePass_success, Message.TitleMessage.TITLE_INFO);
                    users.Password = passNew1;
                    _daoUserDAO.Update(users);
                }
                else
                {
                    ShowMessage(Message.UserMessage.UpdatePassNew1, Message.TitleMessage.TITLE_WARNING);
                }
            }
            else
            {
                ShowMessage(Message.UserMessage.UpdatePass_fail, Message.TitleMessage.TITLE_WARNING);
            }
        }
        #endregion
        #region End
        private void btnLuu_Click(object sender, EventArgs e)
        {
            Update();
        }
        private void btnHuy_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion
    }
}
