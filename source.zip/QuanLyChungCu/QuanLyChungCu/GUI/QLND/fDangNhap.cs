﻿using QuanLyChungCu.DAO;
using QuanLyChungCu.Models;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace QuanLyChungCu.GUI
{
    public partial class fDangNhap : Form
    {
        public static Users UserData;
        private List<Users> listUsers;
        private UserDAO _daoUser;
        private int row = -1;

        #region Menthos
        public fDangNhap()
        {
            InitializeComponent();
            LoadForm();
        }
        private void LoadForm()
        {
            _daoUser = new UserDAO();
        }
        private bool ValidateData()
        {
            if (string.IsNullOrEmpty(txtUserName.Text) || string.IsNullOrEmpty(txtPass.Text))
            {
                return false;
            }
            return true;
        }
        private void ShowMessage(string message, string content = null)
        {
            if (content != null)
            {
                MessageBox.Show(message, content);
            }
            else
                MessageBox.Show(message);
        }
        private Users checkLogin(string username, string pass)
        {
            Users users = _daoUser.GetDataByUserName(username, pass);
            return users;
        }
        private void Login()
        {
            string name = txtUserName.Text;
            string pass = txtPass.Text;
            if (!ValidateData())
            {
                ShowMessage(Message.UserMessage.Validate, Message.TitleMessage.TITLE_WARNING);
                return;
            }
            Users users = checkLogin(name, pass);
            if (users != null)
            {
                UserData = users;
                ShowMessage(Message.UserMessage.Login_success, Message.TitleMessage.TITLE_INFO);
                Form form = new fTrangChu();
                this.Hide();
                form.ShowDialog();
                txtPass.Text = "";
                txtUserName.Text = "";
                this.Show();
            }
            else
                ShowMessage(Message.UserMessage.Login_fail, Message.TitleMessage.TITLE_ERROR);

        }
        #endregion

        #region end
        private void btnLogin_Click(object sender, EventArgs e)
        {
            Login();
        }
        private void cbHienPass_CheckedChanged(object sender, EventArgs e)
        {
            if (cbHienPass.Checked)
            {
                txtPass.UseSystemPasswordChar = false;
            }
            else
                txtPass.UseSystemPasswordChar = true;
        }

        #endregion

        private void fDangNhap_Load(object sender, EventArgs e)
        {

        }
    }
}
