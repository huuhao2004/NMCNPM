﻿namespace QuanLyChungCu.GUI
{
    partial class fTrangChu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fTrangChu));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.quảnLýTàiKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thayĐổiMậtKhẩuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hộGiaĐìnhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nhânKhẩuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hộKhẩuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.phíDịchVụToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.phíGửiXeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.phíĐóngGópToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.phíSinhHoạtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.phíQuảnLýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thốngKêToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thanhToánToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tổngHợpKhoảnThuChiTheoThángToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýTàiKhoảnToolStripMenuItem,
            this.hộGiaĐìnhToolStripMenuItem,
            this.phíDịchVụToolStripMenuItem,
            this.thốngKêToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(875, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // quảnLýTàiKhoảnToolStripMenuItem
            // 
            this.quảnLýTàiKhoảnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thayĐổiMậtKhẩuToolStripMenuItem,
            this.đăngXuấtToolStripMenuItem});
            this.quảnLýTàiKhoảnToolStripMenuItem.Name = "quảnLýTàiKhoảnToolStripMenuItem";
            this.quảnLýTàiKhoảnToolStripMenuItem.Size = new System.Drawing.Size(112, 20);
            this.quảnLýTàiKhoảnToolStripMenuItem.Text = "Quản lý tài khoản";
            // 
            // thayĐổiMậtKhẩuToolStripMenuItem
            // 
            this.thayĐổiMậtKhẩuToolStripMenuItem.Name = "thayĐổiMậtKhẩuToolStripMenuItem";
            this.thayĐổiMậtKhẩuToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.thayĐổiMậtKhẩuToolStripMenuItem.Text = "Thay đổi mật khẩu";
            this.thayĐổiMậtKhẩuToolStripMenuItem.Click += new System.EventHandler(this.thayĐổiMậtKhẩuToolStripMenuItem_Click);
            // 
            // đăngXuấtToolStripMenuItem
            // 
            this.đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            this.đăngXuấtToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.đăngXuấtToolStripMenuItem.Text = "Đăng xuất";
            this.đăngXuấtToolStripMenuItem.Click += new System.EventHandler(this.đăngXuấtToolStripMenuItem_Click);
            // 
            // hộGiaĐìnhToolStripMenuItem
            // 
            this.hộGiaĐìnhToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nhânKhẩuToolStripMenuItem,
            this.hộKhẩuToolStripMenuItem});
            this.hộGiaĐìnhToolStripMenuItem.Name = "hộGiaĐìnhToolStripMenuItem";
            this.hộGiaĐìnhToolStripMenuItem.Size = new System.Drawing.Size(81, 20);
            this.hộGiaĐìnhToolStripMenuItem.Text = "Hộ gia đình";
            // 
            // nhânKhẩuToolStripMenuItem
            // 
            this.nhânKhẩuToolStripMenuItem.Name = "nhânKhẩuToolStripMenuItem";
            this.nhânKhẩuToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.nhânKhẩuToolStripMenuItem.Text = "Nhân khẩu";
            this.nhânKhẩuToolStripMenuItem.Click += new System.EventHandler(this.nhânKhẩuToolStripMenuItem_Click);
            // 
            // hộKhẩuToolStripMenuItem
            // 
            this.hộKhẩuToolStripMenuItem.Name = "hộKhẩuToolStripMenuItem";
            this.hộKhẩuToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.hộKhẩuToolStripMenuItem.Text = "Hộ khẩu";
            this.hộKhẩuToolStripMenuItem.Click += new System.EventHandler(this.hộKhẩuToolStripMenuItem_Click);
            // 
            // phíDịchVụToolStripMenuItem
            // 
            this.phíDịchVụToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.phíGửiXeToolStripMenuItem,
            this.phíĐóngGópToolStripMenuItem,
            this.phíSinhHoạtToolStripMenuItem,
            this.phíQuảnLýToolStripMenuItem});
            this.phíDịchVụToolStripMenuItem.Name = "phíDịchVụToolStripMenuItem";
            this.phíDịchVụToolStripMenuItem.Size = new System.Drawing.Size(78, 20);
            this.phíDịchVụToolStripMenuItem.Text = "Phí dịch vụ";
            // 
            // phíGửiXeToolStripMenuItem
            // 
            this.phíGửiXeToolStripMenuItem.Name = "phíGửiXeToolStripMenuItem";
            this.phíGửiXeToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.phíGửiXeToolStripMenuItem.Text = "Phí gửi xe";
            this.phíGửiXeToolStripMenuItem.Click += new System.EventHandler(this.phíGửiXeToolStripMenuItem_Click);
            // 
            // phíĐóngGópToolStripMenuItem
            // 
            this.phíĐóngGópToolStripMenuItem.Name = "phíĐóngGópToolStripMenuItem";
            this.phíĐóngGópToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.phíĐóngGópToolStripMenuItem.Text = "Phí đóng góp";
            this.phíĐóngGópToolStripMenuItem.Click += new System.EventHandler(this.phíĐóngGópToolStripMenuItem_Click);
            // 
            // phíSinhHoạtToolStripMenuItem
            // 
            this.phíSinhHoạtToolStripMenuItem.Name = "phíSinhHoạtToolStripMenuItem";
            this.phíSinhHoạtToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.phíSinhHoạtToolStripMenuItem.Text = "Phí sinh hoạt";
            this.phíSinhHoạtToolStripMenuItem.Click += new System.EventHandler(this.phíSinhHoạtToolStripMenuItem_Click);
            // 
            // phíQuảnLýToolStripMenuItem
            // 
            this.phíQuảnLýToolStripMenuItem.Name = "phíQuảnLýToolStripMenuItem";
            this.phíQuảnLýToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.phíQuảnLýToolStripMenuItem.Text = "Phí quản lý";
            this.phíQuảnLýToolStripMenuItem.Click += new System.EventHandler(this.phíQuảnLýToolStripMenuItem_Click);
            // 
            // thốngKêToolStripMenuItem
            // 
            this.thốngKêToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thanhToánToolStripMenuItem,
            this.tổngHợpKhoảnThuChiTheoThángToolStripMenuItem});
            this.thốngKêToolStripMenuItem.Name = "thốngKêToolStripMenuItem";
            this.thốngKêToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.thốngKêToolStripMenuItem.Text = "Thống kê";
            // 
            // thanhToánToolStripMenuItem
            // 
            this.thanhToánToolStripMenuItem.Name = "thanhToánToolStripMenuItem";
            this.thanhToánToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.thanhToánToolStripMenuItem.Text = "Thanh toán";
            this.thanhToánToolStripMenuItem.Click += new System.EventHandler(this.thanhToánToolStripMenuItem_Click);
            // 
            // tổngHợpKhoảnThuChiTheoThángToolStripMenuItem
            // 
            this.tổngHợpKhoảnThuChiTheoThángToolStripMenuItem.Name = "tổngHợpKhoảnThuChiTheoThángToolStripMenuItem";
            this.tổngHợpKhoảnThuChiTheoThángToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.tổngHợpKhoảnThuChiTheoThángToolStripMenuItem.Text = "Báo cáo khoản thu theo tháng";
            this.tổngHợpKhoảnThuChiTheoThángToolStripMenuItem.Click += new System.EventHandler(this.tổngHợpKhoảnThuChiTheoThángToolStripMenuItem_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(463, 184);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(196, 210);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label4.Location = new System.Drawing.Point(356, 323);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 22);
            this.label4.TabIndex = 11;
            this.label4.Text = "BLUE MOON";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(339, 94);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(144, 217);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // fTrangChu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(875, 605);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "fTrangChu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TRANG CHỦ";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem phíDịchVụToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem phíGửiXeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem phíĐóngGópToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem phíSinhHoạtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem phíQuảnLýToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hộGiaĐìnhToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nhânKhẩuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýTàiKhoảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thayĐổiMậtKhẩuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đăngXuấtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thốngKêToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thanhToánToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tổngHợpKhoảnThuChiTheoThángToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ToolStripMenuItem hộKhẩuToolStripMenuItem;
        private System.Windows.Forms.Label label4;
    }
}