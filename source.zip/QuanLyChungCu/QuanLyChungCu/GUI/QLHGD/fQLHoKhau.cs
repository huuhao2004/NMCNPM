﻿using QuanLyChungCu.DAO;
using QuanLyChungCu.Models;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace QuanLyChungCu.GUI.QLHGD
{
    public partial class fQLHoKhau : Form
    {
        private List<HoKhau> listHK;
        private HoKhauDAO _hoKhauDAO;
        private int row = -1;
        public fQLHoKhau()
        {
            InitializeComponent();
        }

        private void LoadForm()
        {
            listHK = new List<HoKhau>();
            _hoKhauDAO = new HoKhauDAO();

            txtSoOT.Text = "0";
            txtSoXD.Text = "0";
            txtSoXM.Text = "0";

            dgvQLHK.ColumnCount = 9;
            dgvQLHK.Columns[0].HeaderText = "Mã hộ khẩu";
            dgvQLHK.Columns[0].Width = 100;
            dgvQLHK.Columns[1].HeaderText = "Địa chỉ";
            dgvQLHK.Columns[1].Width = 150;
            dgvQLHK.Columns[2].HeaderText = "Ngày lập";
            dgvQLHK.Columns[2].Width = 100;
            dgvQLHK.Columns[3].HeaderText = "Ngày chuyển đi";
            dgvQLHK.Columns[3].Width = 100;
            dgvQLHK.Columns[4].HeaderText = "Lý do chuyển";
            dgvQLHK.Columns[4].Width = 280;
            dgvQLHK.Columns[5].HeaderText = "Diện tích hộ";
            dgvQLHK.Columns[5].Width = 130;
            dgvQLHK.Columns[6].HeaderText = "Số xe máy";
            dgvQLHK.Columns[6].Width = 130;
            dgvQLHK.Columns[7].HeaderText = "Số ô tô";
            dgvQLHK.Columns[7].Width = 130;
            dgvQLHK.Columns[8].HeaderText = "Số xe đạp";
            dgvQLHK.Columns[8].Width = 130;

            LoadData();
        }

        private void LoadData()
        {
            listHK = _hoKhauDAO.GetAll();
            dgvQLHK.Rows.Clear();
            foreach (HoKhau c in listHK)
            {
                dgvQLHK.Rows.Add(c.MaHoKhau,
                    c.DiaChi,
                    c.NgayLap?.ToString("dd/MM/yyyy"),
                    c.NgayChuyenDi?.ToString("dd/MM/yyyy"),
                    c.LyDoChuyen,
                    c.DienTichHo,
                    c.SoXeMay,
                    c.SoOTo,
                    c.SoXeDap);
            }
        }

        private bool ClickTable()
        {
            if (row < 0 || row > dgvQLHK.Rows.Count - 2)
                return false;
            return true;
        }

        private void SetData(HoKhau hoKhau)
        {
            if (hoKhau != null)
            {
                txtMaHK.Text = hoKhau.MaHoKhau;
                txtDiaChi.Text = hoKhau.DiaChi;
                dtpNgayLap.Value = hoKhau.NgayLap ?? DateTime.Now;
                dtpNgayChuyenDi.Value = hoKhau.NgayChuyenDi ?? DateTime.Now;
                txtLiDo.Text = hoKhau.LyDoChuyen;
                txtDienTich.Text = hoKhau.DienTichHo.ToString();
                txtSoXM.Text = hoKhau.SoXeMay.ToString();
                txtSoXD.Text = hoKhau.SoXeDap.ToString();
                txtSoOT.Text = hoKhau.SoOTo.ToString();
            }
            else
            {
                txtMaHK.Text = "";
                txtDiaChi.Text = "";
                dtpNgayLap.Value = DateTime.Now;
                dtpNgayChuyenDi.Value = DateTime.Now;
                txtLiDo.Text = "";
                txtDienTich.Text = "";
                txtSoXM.Text = "0";
                txtSoXD.Text = "0";
                txtSoOT.Text = "0";


            }
        }

        private HoKhau GetData()
        {
            HoKhau hoKhau = new HoKhau();

            hoKhau.MaHoKhau = txtMaHK.Text;
            hoKhau.DiaChi = txtDiaChi.Text;
            hoKhau.NgayLap = dtpNgayLap.Value;
            hoKhau.NgayChuyenDi = dtpNgayChuyenDi.Value;
            hoKhau.LyDoChuyen = txtLiDo.Text;
            hoKhau.DienTichHo = string.IsNullOrWhiteSpace(txtDienTich.Text) ? 0 : double.Parse(txtDienTich.Text);
            hoKhau.SoXeMay = string.IsNullOrWhiteSpace(txtSoXM.Text) ? 0 : int.Parse(txtSoXM.Text);
            hoKhau.SoXeDap = string.IsNullOrWhiteSpace(txtSoXD.Text) ? 0 : int.Parse(txtSoXD.Text);
            hoKhau.SoOTo = string.IsNullOrWhiteSpace(txtSoOT.Text) ? 0 : int.Parse(txtSoOT.Text);

            return hoKhau;
        }

        private bool ValidateData()
        {
            if (string.IsNullOrEmpty(txtMaHK.Text) ||
                string.IsNullOrEmpty(txtDiaChi.Text) ||
                string.IsNullOrEmpty(txtLiDo.Text) ||
                string.IsNullOrEmpty(txtDienTich.Text) ||
                string.IsNullOrEmpty(txtSoXM.Text) ||
                string.IsNullOrEmpty(txtSoXD.Text) ||
                string.IsNullOrEmpty(txtSoOT.Text))
                return false;
            return true;
        }
        private void ShowMessage(string message, string content = null)
        {

            if (content != null)
            {
                MessageBox.Show(message, content);
            }
            else
                MessageBox.Show(message);
        }


        private void AddCheck()
        {
            if (!ValidateData())
            {
                ShowMessage("Vui lòng nhập đầy đủ thông tin", "Thông báo");
                return;
            }
            if (_hoKhauDAO.FindById(txtMaHK.Text) != null)
            {
                ShowMessage("Mã hộ khẩu đã tồn tại. Vui lòng nhập mã khác.", "Thông báo");
                return;
            }


            try
            {
                HoKhau hoKhau = GetData();
                _hoKhauDAO.Insert(hoKhau);
                ShowMessage("Thêm dữ liệu thành công!");
                Refresh();
                LoadData();
            }
            catch (Exception ex)
            {
                ShowMessage("Đã có lỗi xảy ra! Vui lòng liên hệ với trung tâm tư vấn");
            }
        }

        private void Edit()
        {
            if (!ClickTable())
            {
                ShowMessage("Vui lòng chọn đối tượng", "Thông báo");
                return;
            }
            if (!ValidateData())
            {
                ShowMessage("Vui lòng nhập đầy đủ thông tin", "Thông báo");
                return;
            }

            try
            {
                HoKhau hoKhau = GetData();
                _hoKhauDAO.Update(hoKhau);
                ShowMessage("Cập nhật dữ liệu thành công!");
                LoadData();
            }
            catch (Exception ex)
            {
                ShowMessage("Đã có lỗi xảy ra! Vui lòng liên hệ với trung tâm tư vấn");
            }
        }


        private void Remove()
        {
            if (!ClickTable())
            {
                ShowMessage("Vui lòng chọn đối tượng", "Thông báo");
                return;
            }
            if (MessageBox.Show("Bạn có chắc muốn xóa dữ liệu này không ?", "Cảnh báo"
               , MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }
            if (_hoKhauDAO.IsExistAnotherTable(txtMaHK.Text))
            {
                ShowMessage("Không thể xóa! Dữ liệu hộ khẩu đã tồn tại bên bảng khác.");
                return;
            }
            try
            {
                HoKhau hoKhau = GetData();
                _hoKhauDAO.Delete(hoKhau.MaHoKhau);
                ShowMessage("Xóa dữ liệu thành công!");
                Refresh();
                LoadData();
            }
            catch (Exception ex)
            {
                ShowMessage("Đã có lỗi xảy ra! Vui lòng liên hệ với trung tâm tư vấn");
            }
        }

        private void Refresh()
        {
            SetData(null);
            row = -1;
            txtMaHK.Enabled = true;
        }

        private void btnThemMoi_Click(object sender, EventArgs e)
        {
            AddCheck();
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            Refresh();
        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            Edit();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            Remove();
        }

        private void fQLHoKhau_Load(object sender, EventArgs e)
        {
            LoadForm();
        }

        private void dgvQLHK_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            row = dgvQLHK.CurrentCell.RowIndex;
            if (!ClickTable())
                return;
            SetData(listHK[row]);
            txtMaHK.Enabled = false;
        }

        private void txtTimKiem_TextChanged(object sender, EventArgs e)
        {
            string maKH = txtTimKiem.Text;
            listHK = _hoKhauDAO.GetListByMaHK(maKH);
            dgvQLHK.Rows.Clear();
            foreach (HoKhau c in listHK)
            {
                dgvQLHK.Rows.Add(c.MaHoKhau,
                    c.DiaChi,
                    c.NgayLap?.ToString("dd/MM/yyyy"),
                    c.NgayChuyenDi?.ToString("dd/MM/yyyy"),
                    c.LyDoChuyen,
                    c.DienTichHo,
                    c.SoXeMay,
                    c.SoOTo,
                    c.SoXeDap);
            }
        }
    }
}
