﻿using QuanLyChungCu.DAO;
using QuanLyChungCu.Models;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace QuanLyChungCu.GUI.QLHGD
{
    public partial class fQLNhanKhau : Form
    {
        private List<NhanKhau> listNK;
        private HoKhauDAO _hoKhauDAO;
        private NhanKhauDAO _nhanKhauDAO;
        private int row = -1;
        public fQLNhanKhau()
        {
            InitializeComponent();
        }

        private void LoadForm()
        {
            listNK = new List<NhanKhau>();
            _hoKhauDAO = new HoKhauDAO();
            _nhanKhauDAO = new NhanKhauDAO();

            dgvDSQLNK.ColumnCount = 9;
            dgvDSQLNK.Columns[0].HeaderText = "Mã hộ khẩu";
            dgvDSQLNK.Columns[0].Width = 100;
            dgvDSQLNK.Columns[1].HeaderText = "Họ tên";
            dgvDSQLNK.Columns[1].Width = 150;
            dgvDSQLNK.Columns[2].HeaderText = "CCCD";
            dgvDSQLNK.Columns[2].Width = 100;
            dgvDSQLNK.Columns[3].HeaderText = "Tuổi";
            dgvDSQLNK.Columns[3].Width = 100;
            dgvDSQLNK.Columns[4].HeaderText = "Giới tính";
            dgvDSQLNK.Columns[4].Width = 280;
            dgvDSQLNK.Columns[5].HeaderText = "ĐT";
            dgvDSQLNK.Columns[5].Width = 130;
            dgvDSQLNK.Columns[6].HeaderText = "Quan hệ với chủ hộ";
            dgvDSQLNK.Columns[6].Width = 130;
            dgvDSQLNK.Columns[7].HeaderText = "Tạm trú";
            dgvDSQLNK.Columns[7].Width = 130;
            dgvDSQLNK.Columns[8].HeaderText = "Tạm vắng";
            dgvDSQLNK.Columns[8].Width = 130;

            LoadData();
            LoadHoKhau();
        }

        private void LoadData()
        {
            listNK = _nhanKhauDAO.GetAll();
            dgvDSQLNK.Rows.Clear();
            foreach (NhanKhau c in listNK)
            {
                dgvDSQLNK.Rows.Add(c.MaHoKhau,
                    c.HoTen,
                    c.SoCMND_CCCD,
                    c.Tuoi,
                    c.GioiTinh,
                    c.SoDT,
                    c.LaChuHo == true ? "Là chủ hộ" : c.QuanHe,
                    c.TamTru == 0 ? "Không" : "Có",
                    c.TamVang == 0 ? "Không" : "Có");
            }
        }

        private void LoadHoKhau()
        {
            cbbMaHoKhau.DataSource = _hoKhauDAO.GetAll();
            cbbMaHoKhau.DisplayMember = "MaHoKhau";
            cbbMaHoKhau.ValueMember = "MaHoKhau";
        }

        private bool ClickTable()
        {
            if (row < 0 || row > dgvDSQLNK.Rows.Count - 2)
                return false;
            return true;
        }

        private void SetData(NhanKhau nhanKhau)
        {
            if (nhanKhau != null)
            {
                cbbMaHoKhau.SelectedValue = nhanKhau.MaHoKhau;
                txtCCCD.Text = nhanKhau.SoCMND_CCCD;
                txtHoTen.Text = nhanKhau.HoTen;
                txtTuoi.Text = nhanKhau.Tuoi.ToString();
                txtGioiTinh.Text = nhanKhau.GioiTinh.ToString();
                txtQuanHe.Text = nhanKhau.QuanHe;
                txtSDT.Text = nhanKhau.SoDT;
                cbLaChuHo.Checked = nhanKhau.LaChuHo ?? false;
            }
            else
            {
                txtCCCD.Text = "";
                txtHoTen.Text = "";
                txtTuoi.Text = "";
                txtGioiTinh.Text = "";
                txtQuanHe.Text = "";
                txtSDT.Text = "";
                cbLaChuHo.Checked = false;
            }
        }

        private NhanKhau GetData()
        {
            NhanKhau nhanKhau = new NhanKhau();

            nhanKhau.MaHoKhau = cbbMaHoKhau.SelectedValue.ToString();
            nhanKhau.SoCMND_CCCD = txtCCCD.Text;
            nhanKhau.HoTen = txtHoTen.Text;
            nhanKhau.Tuoi = int.TryParse(txtTuoi.Text, out int tuoi) ? tuoi : 0;
            nhanKhau.GioiTinh = txtGioiTinh.Text;
            nhanKhau.QuanHe = txtQuanHe.Text;
            nhanKhau.SoDT = txtSDT.Text;
            nhanKhau.LaChuHo = cbLaChuHo.Checked;

            return nhanKhau;
        }

        private bool ValidateData()
        {
            if (string.IsNullOrEmpty(txtCCCD.Text) ||
                string.IsNullOrEmpty(txtHoTen.Text) ||
                string.IsNullOrEmpty(txtTuoi.Text) ||
                string.IsNullOrEmpty(txtGioiTinh.Text) ||
                string.IsNullOrEmpty(txtSDT.Text))
            {
                ShowMessage("Vui lòng nhập đầy đủ thông tin");
                return false;
            }

            if (_nhanKhauDAO.IsExistCCCD(txtCCCD.Text))
            {
                ShowMessage("CCCD đã tồn tại.");
                return false;
            }

            return true;
        }
        private void ShowMessage(string message, string content = null)
        {

            if (content != null)
            {
                MessageBox.Show(message, content);
            }
            else
                MessageBox.Show(message);
        }


        private void AddCheck()
        {
            if (!ValidateData())
            {
                return;
            }


            try
            {
                NhanKhau nhanKhau = GetData();
                _nhanKhauDAO.Insert(nhanKhau);
                ShowMessage("Thêm dữ liệu thành công!");
                Refresh();
                LoadData();
            }
            catch (Exception ex)
            {
                ShowMessage("Đã có lỗi xảy ra! Vui lòng liên hệ với trung tâm tư vấn");
            }
        }

        private void Edit()
        {
            if (!ClickTable())
            {
                ShowMessage("Vui lòng chọn đối tượng", "Thông báo");
                return;
            }
            if (!ValidateData())
            {
                ShowMessage("Vui lòng nhập đầy đủ thông tin", "Thông báo");
                return;
            }

            try
            {
                NhanKhau nhanKhau = GetData();
                _nhanKhauDAO.Update(nhanKhau);
                ShowMessage("Cập nhật dữ liệu thành công!");
                LoadData();
            }
            catch (Exception ex)
            {
                ShowMessage("Đã có lỗi xảy ra! Vui lòng liên hệ với trung tâm tư vấn");
            }
        }


        private void Remove()
        {
            if (!ClickTable())
            {
                ShowMessage("Vui lòng chọn đối tượng", "Thông báo");
                return;
            }
            if (MessageBox.Show("Bạn có chắc muốn xóa dữ liệu này không ?", "Cảnh báo"
               , MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }

            try
            {
                NhanKhau nhanKhau = GetData();
                //_nhanKhauDAO.Delete(nhanKhau.ID);
                ShowMessage("Xóa dữ liệu thành công!");
                Refresh();
                LoadData();
            }
            catch (Exception ex)
            {
                ShowMessage("Đã có lỗi xảy ra! Vui lòng liên hệ với trung tâm tư vấn");
            }
        }

        private void Refresh()
        {
            SetData(null);
            row = -1;
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnThemMoi_Click(object sender, EventArgs e)
        {

        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {

        }

        private void btnXoa_Click(object sender, EventArgs e)
        {

        }
    }
}
