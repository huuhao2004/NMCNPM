﻿using QuanLyChungCu.DAO;
using QuanLyChungCu.Models;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace QuanLyChungCu.GUI
{
    public partial class fGiuXe : Form
    {
        private List<HoKhau> listHoKhau;
        private List<PhiGiuXe> listPhiGiuXe;
        private List<BangGiaPhi> listBangGiaPhi;
        private BangGiaPhiDAO _daoBangGia;
        private PhiGiuXeDAO _daoPhiGiuXe;
        private HoKhauDAO _daoHoKhau;
        private int row = -1;

        #region Menthos
        public fGiuXe()
        {
            InitializeComponent();
        }
        private void LoadForm()
        {
            listHoKhau = new List<HoKhau>();
            listPhiGiuXe = new List<PhiGiuXe>();
            _daoPhiGiuXe = new PhiGiuXeDAO();
            _daoHoKhau = new HoKhauDAO();

            dgvThongKeGuiXe.ColumnCount = 16;
            dgvThongKeGuiXe.Columns[0].HeaderText = "Mã phí giữ xe";
            dgvThongKeGuiXe.Columns[0].Width = 100;
            dgvThongKeGuiXe.Columns[1].HeaderText = "Mã hộ khẩu";
            dgvThongKeGuiXe.Columns[1].Width = 100;
            dgvThongKeGuiXe.Columns[2].HeaderText = "Tiền Nộp Mỗi Tháng";
            dgvThongKeGuiXe.Columns[2].Width = 120;
            dgvThongKeGuiXe.Columns[3].HeaderText = "Năm";
            dgvThongKeGuiXe.Columns[3].Width = 70;
            dgvThongKeGuiXe.Columns[4].HeaderText = "Tháng 1";
            dgvThongKeGuiXe.Columns[4].Width = 80;
            dgvThongKeGuiXe.Columns[5].HeaderText = "Tháng 2";
            dgvThongKeGuiXe.Columns[5].Width = 80;
            dgvThongKeGuiXe.Columns[6].HeaderText = "Tháng 3";
            dgvThongKeGuiXe.Columns[6].Width = 80;
            dgvThongKeGuiXe.Columns[7].HeaderText = "Tháng 4";
            dgvThongKeGuiXe.Columns[7].Width = 80;
            dgvThongKeGuiXe.Columns[8].HeaderText = "Tháng 5";
            dgvThongKeGuiXe.Columns[8].Width = 80;
            dgvThongKeGuiXe.Columns[9].HeaderText = "Tháng 6";
            dgvThongKeGuiXe.Columns[9].Width = 80;
            dgvThongKeGuiXe.Columns[10].HeaderText = "Tháng 7";
            dgvThongKeGuiXe.Columns[10].Width = 80;
            dgvThongKeGuiXe.Columns[11].HeaderText = "Tháng 8";
            dgvThongKeGuiXe.Columns[11].Width = 80;
            dgvThongKeGuiXe.Columns[12].HeaderText = "Tháng 9";
            dgvThongKeGuiXe.Columns[12].Width = 80;
            dgvThongKeGuiXe.Columns[13].HeaderText = "Tháng 10";
            dgvThongKeGuiXe.Columns[13].Width = 80;
            dgvThongKeGuiXe.Columns[14].HeaderText = "Tháng 11";
            dgvThongKeGuiXe.Columns[14].Width = 80;
            dgvThongKeGuiXe.Columns[15].HeaderText = "Tháng 12";
            dgvThongKeGuiXe.Columns[15].Width = 80;

            LoadHoKhau();
            LoadFirst();
        }
        private void LoadHoKhau()
        {
            listHoKhau = _daoHoKhau.GetAll();
            cbbMaHK.DataSource = listHoKhau;
            cbbMaHK.DisplayMember = "MaHoKhau";
            cbbMaHK.ValueMember = "MaHoKhau";
        }
        private void LoadFirst()
        {
            listPhiGiuXe = _daoPhiGiuXe.GetAll();
            LoadDS(listPhiGiuXe);
        }
        private void LoadDS(List<PhiGiuXe> listGX)
        {
            dgvThongKeGuiXe.Rows.Clear();
            foreach (PhiGiuXe p in listPhiGiuXe)
            {
                dgvThongKeGuiXe.Rows.Add(p.ID, p.MaHoKhau, p.TienNop, p.Nam,
                    p.Thang1, p.Thang2, p.Thang3, p.Thang4, p.Thang5, p.Thang6, p.Thang7, p.Thang8,
                    p.Thang9, p.Thang10, p.Thang11, p.Thang12);
            }
        }
        private void LoadFormPhuongTien()
        {
            listHoKhau = new List<HoKhau>();
            _daoHoKhau = new HoKhauDAO();

            dgvDSPT.ColumnCount = 4;
            dgvDSPT.Columns[0].HeaderText = "Mã hộ khẩu";
            dgvDSPT.Columns[0].Width = 80;
            dgvDSPT.Columns[1].HeaderText = "Số xe máy";
            dgvDSPT.Columns[1].Width = 80;
            dgvDSPT.Columns[2].HeaderText = "Số xe ô tô";
            dgvDSPT.Columns[2].Width = 80;
            dgvDSPT.Columns[3].HeaderText = "Số xe đạp";
            dgvDSPT.Columns[3].Width = 70;

            LoadHoKhau();
            LoadFirstPT();
        }
        private void LoadFirstPT()
        {
            listHoKhau = _daoHoKhau.GetAll();
            LoadDSPT(listHoKhau);
        }
        private void LoadDSPT(List<HoKhau> listHoKhau)
        {
            dgvDSPT.Rows.Clear();
            foreach (HoKhau p in listHoKhau)
            {
                dgvDSPT.Rows.Add(p.MaHoKhau, p.SoXeMay, p.SoOTo, p.SoXeDap);
            }
        }
        private void LoadFormBangGia()
        {
            listBangGiaPhi = new List<BangGiaPhi>();
            _daoBangGia = new BangGiaPhiDAO();

            dgvBangGiaGuiXe.ColumnCount = 3;
            dgvBangGiaGuiXe.Columns[0].HeaderText = "Giá xe máy";
            dgvBangGiaGuiXe.Columns[0].Width = 100;
            dgvBangGiaGuiXe.Columns[1].HeaderText = "Giá xe ô tô";
            dgvBangGiaGuiXe.Columns[1].Width = 100;
            dgvBangGiaGuiXe.Columns[2].HeaderText = "Giá xe đạp";
            dgvBangGiaGuiXe.Columns[2].Width = 100;

            LoadFirstBangGia();
        }

        private void LoadFirstBangGia()
        {
            listBangGiaPhi = _daoBangGia.GetAll();
            LoadDSBG(listBangGiaPhi);
        }
        private void LoadDSBG(List<BangGiaPhi> listBG)
        {
            dgvBangGiaGuiXe.Rows.Clear();
            foreach (BangGiaPhi p in listBG)
            {
                dgvBangGiaGuiXe.Rows.Add(p.GiaXeMay, p.GiaOTo, p.GiaXeDap);
            }
        }
        private void ShowMessage(string message, string content = null)
        {

            if (content != null)
            {
                MessageBox.Show(message, content);
            }
            else
                MessageBox.Show(message);
        }
        private void Search()
        {
            string maKH = txtTimKiem.Text;
            int nam;
            if (!int.TryParse(txtNam.Text, out nam))
            {
                nam = 0;
            }
            listPhiGiuXe = _daoPhiGiuXe.GetListByMaHK(maKH, nam);
            LoadDS(listPhiGiuXe);
        }
        #endregion
        #region End
        private void fGiuXe_Load(object sender, EventArgs e)
        {
            LoadForm();
            LoadFormPhuongTien();
            LoadFormBangGia();
        }
        private void btnCapNhat1_Click(object sender, EventArgs e)
        {

        }
        private void btnCapNhat_Click(object sender, EventArgs e)
        {

        }
        private void btnLoc_Click_1(object sender, EventArgs e)
        {
            Search();
        }
    }
    #endregion


}
