﻿namespace QuanLyChungCu.GUI
{
    partial class fGiuXe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dgvDSPT = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtNam = new System.Windows.Forms.TextBox();
            this.btnLoc = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvThongKeGuiXe = new System.Windows.Forms.DataGridView();
            this.txtTimKiem = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnSoLuong = new System.Windows.Forms.Button();
            this.cbbMaHK = new System.Windows.Forms.ComboBox();
            this.txtXeD = new System.Windows.Forms.TextBox();
            this.txtXeOT = new System.Windows.Forms.TextBox();
            this.txtSoXM = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dgvBangGiaGuiXe = new System.Windows.Forms.DataGridView();
            this.button2 = new System.Windows.Forms.Button();
            this.txtGiaOT = new System.Windows.Forms.TextBox();
            this.txtGiaXD = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtGiaXM = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSPT)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongKeGuiXe)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBangGiaGuiXe)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dgvDSPT);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(41, 326);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(298, 266);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Danh sách thống kê phương tiện theo hộ gia đình";
            // 
            // dgvDSPT
            // 
            this.dgvDSPT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDSPT.Location = new System.Drawing.Point(2, 36);
            this.dgvDSPT.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dgvDSPT.Name = "dgvDSPT";
            this.dgvDSPT.RowHeadersWidth = 51;
            this.dgvDSPT.RowTemplate.Height = 24;
            this.dgvDSPT.Size = new System.Drawing.Size(293, 201);
            this.dgvDSPT.TabIndex = 7;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtNam);
            this.groupBox2.Controls.Add(this.btnLoc);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.dgvThongKeGuiXe);
            this.groupBox2.Controls.Add(this.txtTimKiem);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(9, 65);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Size = new System.Drawing.Size(962, 256);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            // 
            // txtNam
            // 
            this.txtNam.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNam.Location = new System.Drawing.Point(756, 21);
            this.txtNam.Name = "txtNam";
            this.txtNam.Size = new System.Drawing.Size(99, 30);
            this.txtNam.TabIndex = 37;
            // 
            // btnLoc
            // 
            this.btnLoc.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnLoc.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoc.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnLoc.Location = new System.Drawing.Point(957, 15);
            this.btnLoc.Name = "btnLoc";
            this.btnLoc.Size = new System.Drawing.Size(114, 41);
            this.btnLoc.TabIndex = 36;
            this.btnLoc.Text = "Lọc";
            this.btnLoc.UseVisualStyleBackColor = false;
            this.btnLoc.Click += new System.EventHandler(this.btnLoc_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(678, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 22);
            this.label1.TabIndex = 9;
            this.label1.Text = "Năm";
            // 
            // dgvThongKeGuiXe
            // 
            this.dgvThongKeGuiXe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThongKeGuiXe.Location = new System.Drawing.Point(2, 56);
            this.dgvThongKeGuiXe.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dgvThongKeGuiXe.Name = "dgvThongKeGuiXe";
            this.dgvThongKeGuiXe.RowHeadersWidth = 51;
            this.dgvThongKeGuiXe.RowTemplate.Height = 24;
            this.dgvThongKeGuiXe.Size = new System.Drawing.Size(957, 197);
            this.dgvThongKeGuiXe.TabIndex = 6;
            // 
            // txtTimKiem
            // 
            this.txtTimKiem.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTimKiem.Location = new System.Drawing.Point(243, 17);
            this.txtTimKiem.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtTimKiem.Name = "txtTimKiem";
            this.txtTimKiem.Size = new System.Drawing.Size(236, 26);
            this.txtTimKiem.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(158, 22);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 19);
            this.label2.TabIndex = 4;
            this.label2.Text = "Tìm kiếm";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnSoLuong);
            this.groupBox3.Controls.Add(this.cbbMaHK);
            this.groupBox3.Controls.Add(this.txtXeD);
            this.groupBox3.Controls.Add(this.txtXeOT);
            this.groupBox3.Controls.Add(this.txtSoXM);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(344, 326);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Size = new System.Drawing.Size(298, 266);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Cập nhật số lượng phương tiện theo hộ gia đình";
            // 
            // btnSoLuong
            // 
            this.btnSoLuong.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnSoLuong.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSoLuong.Location = new System.Drawing.Point(140, 273);
            this.btnSoLuong.Name = "btnSoLuong";
            this.btnSoLuong.Size = new System.Drawing.Size(85, 39);
            this.btnSoLuong.TabIndex = 7;
            this.btnSoLuong.Text = "Cập nhật";
            this.btnSoLuong.UseVisualStyleBackColor = false;
            // 
            // cbbMaHK
            // 
            this.cbbMaHK.Location = new System.Drawing.Point(140, 63);
            this.cbbMaHK.Name = "cbbMaHK";
            this.cbbMaHK.Size = new System.Drawing.Size(174, 24);
            this.cbbMaHK.TabIndex = 6;
            // 
            // txtXeD
            // 
            this.txtXeD.Location = new System.Drawing.Point(140, 221);
            this.txtXeD.Name = "txtXeD";
            this.txtXeD.Size = new System.Drawing.Size(174, 24);
            this.txtXeD.TabIndex = 5;
            // 
            // txtXeOT
            // 
            this.txtXeOT.Location = new System.Drawing.Point(140, 164);
            this.txtXeOT.Name = "txtXeOT";
            this.txtXeOT.Size = new System.Drawing.Size(174, 24);
            this.txtXeOT.TabIndex = 4;
            // 
            // txtSoXM
            // 
            this.txtSoXM.Location = new System.Drawing.Point(140, 117);
            this.txtSoXM.Name = "txtSoXM";
            this.txtSoXM.Size = new System.Drawing.Size(174, 24);
            this.txtSoXM.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 224);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 17);
            this.label6.TabIndex = 3;
            this.label6.Text = "Số xe đạp";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 172);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 17);
            this.label5.TabIndex = 2;
            this.label5.Text = "Số ô tô";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 17);
            this.label4.TabIndex = 1;
            this.label4.Text = "Số xe máy";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 17);
            this.label3.TabIndex = 0;
            this.label3.Text = "Mã hộ khẩu";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dgvBangGiaGuiXe);
            this.groupBox4.Controls.Add(this.button2);
            this.groupBox4.Controls.Add(this.txtGiaOT);
            this.groupBox4.Controls.Add(this.txtGiaXD);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.txtGiaXM);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(646, 326);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox4.Size = new System.Drawing.Size(298, 266);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Cập nhật bảng giá gửi xe chung cư";
            // 
            // dgvBangGiaGuiXe
            // 
            this.dgvBangGiaGuiXe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBangGiaGuiXe.Location = new System.Drawing.Point(4, 22);
            this.dgvBangGiaGuiXe.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dgvBangGiaGuiXe.Name = "dgvBangGiaGuiXe";
            this.dgvBangGiaGuiXe.RowHeadersWidth = 51;
            this.dgvBangGiaGuiXe.RowTemplate.Height = 24;
            this.dgvBangGiaGuiXe.Size = new System.Drawing.Size(385, 87);
            this.dgvBangGiaGuiXe.TabIndex = 8;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Location = new System.Drawing.Point(141, 273);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(85, 39);
            this.button2.TabIndex = 14;
            this.button2.Text = "Cập nhật";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // txtGiaOT
            // 
            this.txtGiaOT.Location = new System.Drawing.Point(141, 167);
            this.txtGiaOT.Name = "txtGiaOT";
            this.txtGiaOT.Size = new System.Drawing.Size(174, 24);
            this.txtGiaOT.TabIndex = 12;
            // 
            // txtGiaXD
            // 
            this.txtGiaXD.Location = new System.Drawing.Point(141, 224);
            this.txtGiaXD.Name = "txtGiaXD";
            this.txtGiaXD.Size = new System.Drawing.Size(174, 24);
            this.txtGiaXD.TabIndex = 13;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(25, 125);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 17);
            this.label9.TabIndex = 9;
            this.label9.Text = "Giá xe máy";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(25, 175);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 17);
            this.label8.TabIndex = 10;
            this.label8.Text = "Giá ô tô";
            // 
            // txtGiaXM
            // 
            this.txtGiaXM.Location = new System.Drawing.Point(141, 120);
            this.txtGiaXM.Name = "txtGiaXM";
            this.txtGiaXM.Size = new System.Drawing.Size(174, 24);
            this.txtGiaXM.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 227);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 17);
            this.label7.TabIndex = 11;
            this.label7.Text = "Giá xe đạp";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label10.Location = new System.Drawing.Point(346, 24);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(260, 19);
            this.label10.TabIndex = 12;
            this.label10.Text = "QUẢN LÝ PHÍ GIỮ XE CHUNG CƯ";
            // 
            // fGiuXe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(980, 600);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "fGiuXe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QUẢN LÝ GỬI XE";
            this.Load += new System.EventHandler(this.fGiuXe_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSPT)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongKeGuiXe)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBangGiaGuiXe)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dgvThongKeGuiXe;
        private System.Windows.Forms.TextBox txtTimKiem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dgvDSPT;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnSoLuong;
        private System.Windows.Forms.ComboBox cbbMaHK;
        private System.Windows.Forms.TextBox txtXeD;
        private System.Windows.Forms.TextBox txtXeOT;
        private System.Windows.Forms.TextBox txtSoXM;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtGiaOT;
        private System.Windows.Forms.TextBox txtGiaXD;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtGiaXM;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dgvBangGiaGuiXe;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLoc;
        private System.Windows.Forms.TextBox txtNam;
    }
}