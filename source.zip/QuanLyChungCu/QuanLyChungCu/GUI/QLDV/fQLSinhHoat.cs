﻿using QuanLyChungCu.DAO;
using QuanLyChungCu.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyChungCu.GUI.QLDV
{
    public partial class fQLSinhHoat : Form
    {
        private List<PhiSinhHoat> listPhiSH;
        private List<HoKhau> listHoKhau;
        private PhiSinhHoatDAO _daoPhiSinhHoat;
        private HoKhauDAO _daoHoKhau;

        #region Menthos
        public fQLSinhHoat()
        {
            InitializeComponent();
        }
        private void LoadForm()
        {
            listHoKhau = new List<HoKhau>();
            listPhiSH = new List<PhiSinhHoat>();
            _daoHoKhau= new HoKhauDAO();
            _daoPhiSinhHoat= new PhiSinhHoatDAO();

            dgvDSPhiSH.ColumnCount = 7;
            dgvDSPhiSH.Columns[0].HeaderText = "Mã phí sinh hoạt";
            dgvDSPhiSH.Columns[0].Width = 150;
            dgvDSPhiSH.Columns[1].HeaderText = "Mã hộ khẩu";
            dgvDSPhiSH.Columns[1].Width = 200;
            dgvDSPhiSH.Columns[2].HeaderText = "Tiền điện";
            dgvDSPhiSH.Columns[2].Width = 120;
            dgvDSPhiSH.Columns[3].HeaderText = "Tiện nước";
            dgvDSPhiSH.Columns[3].Width = 120;
            dgvDSPhiSH.Columns[4].HeaderText = "Tiền Internet";
            dgvDSPhiSH.Columns[4].Width = 120;
            dgvDSPhiSH.Columns[5].HeaderText = "Tháng";
            dgvDSPhiSH.Columns[5].Width = 80;
            dgvDSPhiSH.Columns[6].HeaderText = "Năm";
            dgvDSPhiSH.Columns[6].Width = 80;

            LoadHoKhau();
            LoadFirst();

        }
        private void LoadHoKhau()
        {
            listHoKhau = _daoHoKhau.GetAll();
            cbbMaHK.DataSource = listHoKhau;
            cbbMaHK.DisplayMember = "MaHoKhau";
            cbbMaHK.ValueMember = "MaHoKhau";
        }
        
        private void LoadFirst()
        {
            listPhiSH = _daoPhiSinhHoat.GetAll();
            LoadDS(listPhiSH);
        }
        private void LoadDS(List<PhiSinhHoat> listSH)
        {
            dgvDSPhiSH.Rows.Clear();
            foreach (PhiSinhHoat p in listPhiSH)
            {
                dgvDSPhiSH.Rows.Add(p.ID, p.MaHoKhau, p.TienDien, p.TienNuoc, p.TienInternet,p.Thang,p.Nam);
            }
        }
        private void ShowMessage(string message, string content = null)
        {

            if (content != null)
            {
                MessageBox.Show(message, content);
            }
            else
                MessageBox.Show(message);
        }
        private void Search()
        {
            string maKH = txtTimKiem.Text;
            int nam;
            if (!int.TryParse(txtNam.Text, out nam))
            {
                nam = 0;
            }

            listPhiSH = _daoPhiSinhHoat.GetListByMaHK(maKH, nam);
            LoadDS(listPhiSH);
        }
        private void dgvDSPhiSH_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        #endregion
        #region End
        private void btnLoc_Click(object sender, EventArgs e)
        {
            Search();
        }
        private void fQLSinhHoat_Load(object sender, EventArgs e)
        {
            LoadForm();
        }
        private void btnCapNhat_Click(object sender, EventArgs e)
        {

        }
        #endregion


    }
}
