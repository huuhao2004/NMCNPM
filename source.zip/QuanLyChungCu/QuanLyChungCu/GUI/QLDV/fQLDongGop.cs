﻿using QuanLyChungCu.DAO;
using QuanLyChungCu.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyChungCu.GUI.QLDV
{
    public partial class fQLDongGop : Form
    {
        private List<LoaiPhi> listLoaiPhi;
        private List<HoKhau> listHoKhau;
        private List<PhiDongGop> listPhiDongGop;
        private HoKhauDAO _daoHoKhau;
        private LoaiPhiDAO _daoLoaiPhi;
        private PhiDongGopDAO _daoDongGop;
        private int row = -1;

        #region Menthos
        public fQLDongGop()
        {
            InitializeComponent();
        }
        private void LoadForm() {
            listLoaiPhi= new List<LoaiPhi>();
            listHoKhau= new List<HoKhau>();
            listPhiDongGop= new List<PhiDongGop>();
            _daoHoKhau= new HoKhauDAO();
            _daoLoaiPhi= new LoaiPhiDAO();
            _daoDongGop= new PhiDongGopDAO();

            dgvQLDG.ColumnCount = 6;
            dgvQLDG.Columns[0].HeaderText = "Mã phí đóng góp";
            dgvQLDG.Columns[0].Width = 130;
            dgvQLDG.Columns[1].HeaderText = "Tên phí đóng góp";
            dgvQLDG.Columns[1].Width = 200;
            dgvQLDG.Columns[2].HeaderText = "Mã hộ khẩu";
            dgvQLDG.Columns[2].Width = 120;
            dgvQLDG.Columns[3].HeaderText = "Mã loại phí";
            dgvQLDG.Columns[3].Width = 120;
            dgvQLDG.Columns[4].HeaderText = "Số tiền";
            dgvQLDG.Columns[4].Width = 150;
            dgvQLDG.Columns[5].HeaderText = "Ngày đóng góp";
            dgvQLDG.Columns[5].Width = 120;

            LoadHoKhau();
            LoadFirst();
            LoadLoaiPhi();
        }
        
        private void LoadHoKhau()
        {
            listHoKhau = _daoHoKhau.GetAll();
            cbbMaHK.DataSource = listHoKhau;
            cbbMaHK.DisplayMember = "MaHoKhau";
            cbbMaHK.ValueMember = "MaHoKhau";
        }
        private void LoadFirst()
        {
            listPhiDongGop = _daoDongGop.GetAll();
            LoadDS(listPhiDongGop);
        }
        private void LoadDS(List<PhiDongGop> listPhiDongGop)
        {
            dgvQLDG.Rows.Clear();
            foreach (PhiDongGop p in listPhiDongGop)
            {
                dgvQLDG.Rows.Add(p.ID, p.TenPhi, p.MaHoKhau, p.IdLoaiPhi, p.SoTien, p.NgayDongGop);
            }
        }
        private void LoadFormLoaiPhi()
        {
            _daoLoaiPhi = new LoaiPhiDAO();
            listLoaiPhi = new List<LoaiPhi>();

            dgvLoaiPhi.ColumnCount = 3;
            dgvLoaiPhi.Columns[0].HeaderText = "Mã loại phí";
            dgvLoaiPhi.Columns[0].Width = 90;
            dgvLoaiPhi.Columns[1].HeaderText = "Tên loại phí";
            dgvLoaiPhi.Columns[1].Width = 100;
            dgvLoaiPhi.Columns[2].HeaderText = "Mô tả";
            dgvLoaiPhi.Columns[2].Width = 200;

            LoadLoaiPhi();
            LoadFirst1();
        }
        private void LoadLoaiPhi()
        {
            listLoaiPhi = _daoLoaiPhi.GetAll();
            cbbMaLoai.DataSource = listLoaiPhi;
            cbbMaLoai.DisplayMember = "TenLoaiPhi";
            cbbMaLoai.ValueMember = "ID";
        }
        private void LoadFirst1()
        {
            listLoaiPhi = _daoLoaiPhi.GetAll();
            LoadDS1(listLoaiPhi);
        }
        private void LoadDS1(List<LoaiPhi> listLoaiPhi)
        {
            dgvLoaiPhi.Rows.Clear();
            foreach (LoaiPhi p in listLoaiPhi)
            {
                dgvLoaiPhi.Rows.Add(p.ID, p.TenLoaiPhi, p.MoTa);
            }
        }
        
        private void ShowMessage(string message, string content = null)
        {

            if (content != null)
            {
                MessageBox.Show(message, content);
            }
            else
                MessageBox.Show(message);
        }
        private PhiDongGop GetData()
        {
            PhiDongGop phiDongGop = new PhiDongGop();
            if (!string.IsNullOrEmpty(txtSoXM.Text)) ;
            return phiDongGop;
        }
        private bool UpdatePhiDG()
        {
            PhiDongGop phi = GetData();
            phi.MaHoKhau = listHoKhau[row].MaHoKhau;

            PhiDongGop phiDongGop = _daoDongGop.FindById(phi.MaHoKhau);
            phiDongGop.SoTien = phi.SoTien;
            return _daoDongGop.Update(phiDongGop);
        }
        private void Edit()
        {
            if (string.IsNullOrEmpty(txtSoXM.Text))
            {

            }
            else
            {
                LoadForm();
            }
        }
        private bool ClickTable()
        {
            if (row < 0 || row > dgvQLDG.Rows.Count - 2)
                return false;
            return true;
        }
        private void dgvQLDG_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            row = e.RowIndex;
            if (!ClickTable())
            {
                return;
            }
        }
        private void dgvLoaiPhi_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            row = e.RowIndex;
            if (!ClickTable())
            {
                return;
            }
        }
        private void Search()
        {
            string maKH = txtTimKiem.Text;

            listPhiDongGop = _daoDongGop.GetListByMaHK(maKH);
            LoadDS(listPhiDongGop);
        }
        #endregion

        #region End
        private void btnCapnhat_Click(object sender, EventArgs e)
        {
            Edit();
        }
        private void btnLoc_Click(object sender, EventArgs e)
        {
            Search();
        }
        private void fQLDongGop_Load(object sender, EventArgs e)
        {
            LoadForm();
            LoadFormLoaiPhi();
        }

        #endregion
    }
}
