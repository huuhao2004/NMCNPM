﻿using QuanLyChungCu.DAO;
using QuanLyChungCu.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows.Forms;

namespace QuanLyChungCu.GUI.QLDV
{
    public partial class fQLChungCu : Form
    {
        List<PhiQuanLy> listQuanLy;
        List<HoKhau> listHoKhau;
        private PhiQuanLyDAO _daoPhiQuanLy;
        private BangGiaPhiDAO _giaDAO;
        private HoKhauDAO _daoHoKhau;
        private int row = -1;
        private BangGiaPhi _bangGia;

        #region Menthos
        public fQLChungCu()
        {
            InitializeComponent();
        }
        private void LoadForm()
        {
            listQuanLy = new List<PhiQuanLy>();
            listHoKhau = new List<HoKhau>();
            _daoPhiQuanLy = new PhiQuanLyDAO();
            _daoHoKhau = new HoKhauDAO();
            _giaDAO = new BangGiaPhiDAO();

            txtInputNam.Text = DateTime.Now.Year.ToString();

            dgvDSCC.ColumnCount = 15;
            dgvDSCC.Columns[0].HeaderText = "Mã hộ khẩu";
            dgvDSCC.Columns[0].Width = 100;
            dgvDSCC.Columns[1].HeaderText = "Tiền Nộp Mỗi Tháng";
            dgvDSCC.Columns[1].Width = 120;
            dgvDSCC.Columns[2].HeaderText = "Năm";
            dgvDSCC.Columns[2].Width = 70;
            dgvDSCC.Columns[3].HeaderText = "Tháng 1";
            dgvDSCC.Columns[3].Width = 80;
            dgvDSCC.Columns[4].HeaderText = "Tháng 2";
            dgvDSCC.Columns[4].Width = 80;
            dgvDSCC.Columns[5].HeaderText = "Tháng 3";
            dgvDSCC.Columns[5].Width = 80;
            dgvDSCC.Columns[6].HeaderText = "Tháng 4";
            dgvDSCC.Columns[6].Width = 80;
            dgvDSCC.Columns[7].HeaderText = "Tháng 5";
            dgvDSCC.Columns[7].Width = 80;
            dgvDSCC.Columns[8].HeaderText = "Tháng 6";
            dgvDSCC.Columns[8].Width = 80;
            dgvDSCC.Columns[9].HeaderText = "Tháng 7";
            dgvDSCC.Columns[9].Width = 80;
            dgvDSCC.Columns[10].HeaderText = "Tháng 8";
            dgvDSCC.Columns[10].Width = 80;
            dgvDSCC.Columns[11].HeaderText = "Tháng 9";
            dgvDSCC.Columns[11].Width = 80;
            dgvDSCC.Columns[12].HeaderText = "Tháng 10";
            dgvDSCC.Columns[12].Width = 80;
            dgvDSCC.Columns[13].HeaderText = "Tháng 11";
            dgvDSCC.Columns[13].Width = 80;
            dgvDSCC.Columns[14].HeaderText = "Tháng 12";
            dgvDSCC.Columns[14].Width = 80;

            LoadFirst();
            LoadHoKhau();
            LoadThang();
        }
        private void LoadHoKhau()
        {
            listHoKhau = _daoHoKhau.GetAll();
            cbbMaHK.DataSource = listHoKhau;
            cbbMaHK.DisplayMember = "MaHoKhau";
            cbbMaHK.ValueMember = "MaHoKhau";
        }

        private void LoadThang()
        {
            List<string> thangs = new List<string> { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" };
            cbbThang.DataSource = thangs;
        }

        private void LoadFirst()
        {
            listQuanLy = _daoPhiQuanLy.GetAll();
            LoadDS(listQuanLy);
        }

        private void LoadDS(List<PhiQuanLy> listQl)
        {
            dgvDSCC.Rows.Clear();
            foreach (PhiQuanLy p in listQl)
            {
                dgvDSCC.Rows.Add(p.MaHoKhau, p.TienNopMoiThang, p.Nam,
                    p.Thang1, p.Thang2, p.Thang3, p.Thang4, p.Thang5, p.Thang6, p.Thang7, p.Thang8,
                    p.Thang9, p.Thang10, p.Thang11, p.Thang12);
            }
        }
        private void ShowMessage(string message, string content = null)
        {

            if (content != null)
            {
                MessageBox.Show(message, content);
            }
            else
                MessageBox.Show(message);
        }
        private PhiQuanLy GetData()
        {
            PhiQuanLy phiQuanLy = new PhiQuanLy();

            string maHK = cbbMaHK.SelectedValue.ToString();
            int thang = int.Parse(cbbThang.SelectedValue.ToString());
            int nam = int.Parse(txtInputNam.Text);
            decimal price = decimal.Parse(txtSoTien.Text);

            phiQuanLy.MaHoKhau = maHK;
            phiQuanLy.Nam = nam;

            switch (thang)
            {
                case 1:
                    phiQuanLy.Thang1 = price;
                    break;
                case 2:
                    phiQuanLy.Thang2 = price;
                    break;
                case 3:
                    phiQuanLy.Thang3 = price;
                    break;
                case 4:
                    phiQuanLy.Thang4 = price;
                    break;
                case 5:
                    phiQuanLy.Thang5 = price;
                    break;
                case 6:
                    phiQuanLy.Thang6 = price;
                    break;
                case 7:
                    phiQuanLy.Thang7 = price;
                    break;
                case 8:
                    phiQuanLy.Thang8 = price;
                    break;
                case 9:
                    phiQuanLy.Thang9 = price;
                    break;
                case 10:
                    phiQuanLy.Thang10 = price;
                    break;
                case 11:
                    phiQuanLy.Thang11 = price;
                    break;
                case 12:
                    phiQuanLy.Thang12 = price;
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(thang), "Tháng phải nằm trong khoảng từ 1 đến 12.");
            }
            return phiQuanLy;
        }
        private void Edit()
        {
            if (string.IsNullOrEmpty(txtSoTien.Text))
            {
                ShowMessage("Số tiền không được bỏ trống");
            }
            else
            {
                decimal price = decimal.Parse(txtSoTien.Text);
                decimal priceMin = decimal.Parse(lbTien.Text, NumberStyles.Currency, CultureInfo.CurrentCulture);
                if (price < priceMin)
                {
                    ShowMessage("Số tiền cần đóng phải lớn hơn số tiền tối thiểu");
                    return;
                }
                int thang = int.Parse(cbbThang.SelectedValue.ToString());
                PhiQuanLy phiQuanLy = GetData();
                _daoPhiQuanLy.UpdatePhiQuanLy(phiQuanLy, thang);
                LoadForm();
            }
        }
        private bool ClickTable()
        {
            if (row < 0 || row > dgvDSCC.Rows.Count - 2)
                return false;
            return true;
        }
        private void dgvDSCC_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            row = e.RowIndex;
            if (!ClickTable())
            {
                return;
            }
        }
        private void Search()
        {
            string maKH = txtTimKiem.Text;
            int nam;
            if (!int.TryParse(txtNam.Text, out nam))
            {
                nam = 0;
            }

            listQuanLy = _daoPhiQuanLy.GetListByMaHK(maKH, nam);
            LoadDS(listQuanLy);
        }

        private void GetTotalPrice()
        {
            string maHK = cbbMaHK.SelectedValue?.ToString();
            int thang = cbbThang.SelectedValue == null ? 1 : int.Parse(cbbThang.SelectedValue?.ToString());
            int nam = int.Parse(txtInputNam.Text);

            txtSoTien.Text = _daoPhiQuanLy.GetMoney(maHK, nam, thang).ToString();
        }

        private void CalTotlPrice()
        {
            string maHK = cbbMaHK.SelectedValue.ToString();
            var bangGia = _giaDAO.GetLast();
            HoKhau hoKhau = _daoHoKhau.FindById(maHK);
            if (bangGia != null && hoKhau != null)
            {
                _bangGia = bangGia;
                decimal price = (decimal)(hoKhau.DienTichHo ?? 0) * (bangGia.GiaQuanLy ?? 0);
                lbTien.Text = price.ToString("C");
            }
            else
            {
                lbTien.Text = "0";
            }
        }
        #endregion

        #region End
        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            Edit();
        }
        private void fQLChungCu_Load(object sender, EventArgs e)
        {
            LoadForm();
        }

        private void btnLoc_Click(object sender, EventArgs e)
        {
            Search();
        }


        #endregion

        private void txtSoTien_TextChanged(object sender, EventArgs e)
        {

        }

        private void cbbMaHK_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetTotalPrice();
            CalTotlPrice();
        }

        private void cbbThang_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetTotalPrice();
            CalTotlPrice();
        }
    }
}
