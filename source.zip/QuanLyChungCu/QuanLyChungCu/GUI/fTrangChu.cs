﻿using QuanLyChungCu.GUI.QLDV;
using QuanLyChungCu.GUI.QLHGD;
using QuanLyChungCu.GUI.QLThongKe;
using System;
using System.Windows.Forms;

namespace QuanLyChungCu.GUI
{
    public partial class fTrangChu : Form
    {
        public fTrangChu()
        {
            InitializeComponent();
        }

        private void thayĐổiMậtKhẩuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new fUpdateUser();
            this.Hide();
            form.ShowDialog();
            this.Show();
        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new fDangNhap();
            this.Hide();
            form.ShowDialog();
            this.Show();
        }

        private void nhânKhẩuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new fQLNhanKhau();
            this.Hide();
            form.ShowDialog();
            this.Show();
        }

        private void hộKhẩuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new fQLHoKhau();
            this.Hide();
            form.ShowDialog();
            this.Show();
        }

        private void phíGửiXeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new fGiuXe();
            this.Hide();
            form.ShowDialog();
            this.Show();
        }

        private void phíĐóngGópToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new fQLDongGop();
            this.Hide();
            form.ShowDialog();
            this.Show();
        }

        private void phíSinhHoạtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new fQLSinhHoat();
            this.Hide();
            form.ShowDialog();
            this.Show();
        }

        private void phíQuảnLýToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new fQLChungCu();
            this.Hide();
            form.ShowDialog();
            this.Show();
        }

        private void thanhToánToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new fThanhToan();
            this.Hide();
            form.ShowDialog();
            this.Show();

        }

        private void tổngHợpKhoảnThuChiTheoThángToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new fThanhToan();
            this.Hide();
            form.ShowDialog();
            this.Show();
        }
    }
}
